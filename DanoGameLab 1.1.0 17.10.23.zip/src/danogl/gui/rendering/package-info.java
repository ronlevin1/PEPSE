/**
 * Visual representations of objects
 * @author Dan Nirel
 */
package danogl.gui.rendering;